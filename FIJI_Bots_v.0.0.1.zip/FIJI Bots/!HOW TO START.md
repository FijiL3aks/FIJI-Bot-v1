
███████╗██╗░░░░░██╗██╗  ██████╗░░█████╗░████████╗░██████╗
██╔════╝██║░░░░░██║██║  ██╔══██╗██╔══██╗╚══██╔══╝██╔════╝
█████╗░░██║░░░░░██║██║  ██████╦╝██║░░██║░░░██║░░░╚█████╗░
██╔══╝░░██║██╗░░██║██║  ██╔══██╗██║░░██║░░░██║░░░░╚═══██╗
██║░░░░░██║╚█████╔╝██║  ██████╦╝╚█████╔╝░░░██║░░░██████╔╝
╚═╝░░░░░╚═╝░╚════╝░╚═╝  ╚═════╝░░╚════╝░░░░╚═╝░░░╚═════╝░  Lobby Bot Network v.0.0.1                                                                                                       
//////////////////////////////////////////////////////////////////////////////////////
Next Gen of Lobby Bots!
The "FIJI Bots" are the best lobby bots you ever seen!



IF YOU HAVE ANY PROBLEMS CONTACT ME ON DISCORD : FIJI#9999



HOW TO START THE FIJI BOTS!

1.Go in the "config" to costumize your bot  [Make NOTHING in "auth"]

2.Click on "INSTALL PACKAGES.BAT" 

3. Click on "START.BAT"

4.LET IT OPEN!!!

5.Get your auth code on this website :
https://www.epicgames.com/id/api/redirect?clientId=3446cd72694c4a4485d81b77adbb2141&responseType=code

6.Paste the code in "START.BAT" and wait

7.Have FUN :3


 